namespace Exterminator.Models.Dtos
{
    public class GhostbusterDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Expertize { get; set; }
    }
}