﻿using System;

namespace CleanThatCode.Community.Models
{
    public class Class1
    {
    }
}
